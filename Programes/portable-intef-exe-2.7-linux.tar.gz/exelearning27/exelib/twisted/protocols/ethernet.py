from twisted.python import util

util.moduleMovedForSplit('twisted.protocols.ethernet', 'twisted.pair.ethernet',
                         'Ethernet Protocol', 'Pair',
                         'http://twistedmatrix.com/projects/pair',
                         globals())

