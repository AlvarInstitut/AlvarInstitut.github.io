from twisted.python import util

util.moduleMovedForSplit('twisted.protocols.rawudp', 'twisted.pair.rawudp',
                         'Raw UDP', 'Pair',
                         'http://twistedmatrix.com/projects/pair',
                         globals())

