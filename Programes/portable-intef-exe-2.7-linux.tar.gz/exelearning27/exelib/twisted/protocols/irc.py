from twisted.python import util

util.moduleMovedForSplit('twisted.protocols.irc', 'twisted.words.protocols.irc',
                         'IRC protocol support', 'Words',
                         'http://twistedmatrix.com/projects/words',
                         globals())

