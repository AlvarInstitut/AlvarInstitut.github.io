translations = {
 "": "Project-Id-Version: eXeLearning 2.7\nReport-Msgid-Bugs-To: \nPOT-Creation-Date: 2022-04-22 12:24+0200\nPO-Revision-Date: 2006-09-22 10:21+1200\nLast-Translator: EXE Team <exe@exelearning.org>\nLanguage: ig\nLanguage-Team: EXE Team <exe@exelearning.org>\nPlural-Forms: nplurals=2; plural=(n != 1)\nMIME-Version: 1.0\nContent-Type: text\/plain; charset=utf-8\nContent-Transfer-Encoding: 8bit\nGenerated-By: Babel 2.9.1\n", 
 "?????": "?????"
};
