var tinyMCETemplateList = [
	["2 zutabe 50% 50%", "/scripts/tinymce_templates/2-50-50.html"],
	["2 zutabe 30% 70%", "/scripts/tinymce_templates/2-30-70.html"],
	["2 zutabe 70% 30%", "/scripts/tinymce_templates/2-70-30.html"],
	["3 zutabe", "/scripts/tinymce_templates/3.html"]
];