var tinyMCETemplateList = [
	["2 columnas 50% 50%", "/scripts/tinymce_templates/2-50-50.html"],
	["2 columnas 30% 70%", "/scripts/tinymce_templates/2-30-70.html"],
	["2 columnas 70% 30%", "/scripts/tinymce_templates/2-70-30.html"],
	["3 columnas", "/scripts/tinymce_templates/3.html"]
];